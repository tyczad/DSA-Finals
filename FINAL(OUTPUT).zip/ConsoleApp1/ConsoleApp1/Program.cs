﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            while (!exit)
            {
                DisplayMenu();
                int choice = GetChoice();

                switch (choice)
                {
                    case 1:
                        RecursiveAndIterative();
                        break;
                    case 2:
                        RunArrays();
                        break;
                    case 3:
                        StringManipulation();
                        break;
                    case 4:
                        Sets();
                        break;
                    case 5:
                        RunStacks();
                        break;
                    case 6:
                        RunQueue();
                        break;
                    case 7:
                        LinkedLists();
                        break;
                    case 8:
                        BinaryTree();
                        break;
                    case 9:
                        Graph();
                        break;
                    case 10:
                        Sorting();
                        break;
                    case 11:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid Choice. Please try again!");
                        break;

                }

                Console.WriteLine();
            }

            Console.WriteLine("Exiting the compiler....");
        }

        static void DisplayMenu()
        {
            Console.WriteLine("=======================================");
            Console.WriteLine("||                                   ||");
            Console.WriteLine("|| Welcome to my Final Output on DSA ||");
            Console.WriteLine("||                                   ||");
            Console.WriteLine("=======================================");
            Console.WriteLine("1. Recursive And Iterative");
            Console.WriteLine("2. Arrys");
            Console.WriteLine("3. String Manipulation");
            Console.WriteLine("4. Sets");
            Console.WriteLine("5. Stacks");
            Console.WriteLine("6. Queue");
            Console.WriteLine("7. Linked Lists");
            Console.WriteLine("8. Binary Tree");
            Console.WriteLine("9. Graph");
            Console.WriteLine("10. Sorting");
            Console.WriteLine("11. Exit");
            Console.WriteLine();
            Console.Write("Enter the number of your choice: ");
        }

        static int GetChoice()
        {
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out int choice))
                    return choice;

                Console.WriteLine("Invalid input. Please enter a valid number.");
            }
        }

        static void RecursiveAndIterative()
        {
            Console.WriteLine("1. Towers of Hanoi");
            Console.WriteLine("2. Fibonacci (Iterative)");
            Console.WriteLine("3. Fibonacci Recursive (GCD)");
            Console.Write("Enter the number of your choice: ");
            int choice = GetChoice();

            switch (choice)
            {
                case 1:
                    TowerOfHanoi();
                    break;
                case 2:
                    Iterative();
                    break;
                case 3:
                    Recursive();
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }

            static void TowerOfHanoi()
            {
                Console.WriteLine("Enter the number of disks: ");
                int numberOfDisks = int.Parse(Console.ReadLine());

                int numberOfMoves = (int)(Math.Pow(2, numberOfDisks) - 1);

                Console.WriteLine("The minimum number of moves: " + numberOfMoves);
                Console.ReadLine();
            }

            static void Iterative()
            {
                Console.WriteLine("Enter the nth number: ");
                int n = int.Parse(Console.ReadLine());
                Console.WriteLine("The " + n + "th Fiboncci number is: " + Fibonacci(n));
                Console.ReadLine();
            }

            static double Fibonacci(int n)
            {
                double phi = (1 + Math.Sqrt(5)) / 2;
                double psi = (1 - Math.Sqrt(5)) / 2;
                return (Math.Pow(phi, n) - Math.Pow(psi, n)) / Math.Sqrt(5);
            }

            static void Recursive()
            {
                Console.WriteLine("Enter the first number: ");
                int num1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Enther the second number: ");
                int num2 = int.Parse(Console.ReadLine());
                Console.WriteLine("The GCD of " + num1 + " and " + num2 + " is " + GCD(num1, num2));

                Console.ReadKey();
            }

            static int GCD(int num1, int num2)
            {
                if (num2 == 0)
                    return num1;
                return GCD(num2, num1 % num2);
            }
        }

        static void RunArrays()
        {
            Console.WriteLine("Executing Arrays work...");

            Console.WriteLine("1. Highest GWA");
            Console.WriteLine("2. Covid-19 data");
            Console.Write("Enter the number of your choice: ");
            int choice = GetChoice();

            switch (choice)
            {
                case 1:
                    RunGWA();
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }

        static void RunGWA()
        {
            string[,] classmates = new string[10, 2];

            for (int i = 0; i < classmates.GetLength(0); i++)
            {
                Console.Write("Enter name of classmate {0}: ", i + 1);
                classmates[i, 0] = Console.ReadLine();

                Console.Write("Enter Prelim GWA of classmate {0}: ", i + 1);
                classmates[i, 1] = Console.ReadLine();
            }

            for (int i = 0; i < classmates.GetLength(0) - 1; i++)
            {
                for (int j = i + 1; j < classmates.GetLength(0); j++)
                {
                    if (double.Parse(classmates[i, 1]) < double.Parse(classmates[j, 1]))
                    {
                        string tempName = classmates[i, 0];
                        string tempGwa = classmates[i, 1];

                        classmates[i, 0] = classmates[j, 0];
                        classmates[i, 1] = classmates[j, 1];

                        classmates[j, 0] = tempName;
                        classmates[j, 1] = tempGwa;
                    }
                }
            }

            Console.WriteLine("\nClassmates sorted by highest Prelim GWA:");
            for (int i = 0; i < classmates.GetLength(0); i++)
            {
                Console.WriteLine("{0}. {1} - {2}", i + 1, classmates[i, 0], classmates[i, 1]);
            }
        }

        static void StringManipulation()
        {
            Console.WriteLine("Enter Something: ");
            string Input = Console.ReadLine();

            Console.WriteLine("Select your Method in the Menu:");
            Console.WriteLine("1. Clone.");
            Console.WriteLine("2. Length.");
            Console.WriteLine("3. ToUpper.");
            Console.WriteLine("4. ToLower.");
            Console.WriteLine("5. Trim.");
            Console.WriteLine("6. Contains.");
            Console.WriteLine("7. ToCharArray.");
            Console.WriteLine("8. Substring.");
            Console.WriteLine("9. StartsWith.");
            Console.WriteLine("10. Split.");
            Console.WriteLine("11. EndsWith.");
            Console.WriteLine("12. IndexOf.");
            Console.WriteLine("13. LastIndexOf");
            Console.WriteLine("14. Replace.");
            Console.WriteLine("15. Reverse.");

            int Menu = int.Parse(Console.ReadLine());
            switch (Menu)
            {
                case 1:
                    Console.WriteLine(Input.Clone());
                    break;
                case 2:
                    Console.WriteLine(Input.Length);
                    break;
                case 3:
                    Console.WriteLine(Input.ToUpper());
                    break;
                case 4:
                    Console.WriteLine(Input.ToLower());
                    break;
                case 5:
                    Console.WriteLine(Input.Trim());
                    break;
                case 6:
                    Console.WriteLine("Checking: ");
                    string searchSubstring = Console.ReadLine();
                    Console.WriteLine(Input.Contains(searchSubstring));
                    break;
                case 7:
                    Console.WriteLine(Input.ToCharArray());
                    break;
                case 8:
                    Console.WriteLine("Checking: ");
                    int startIndex = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter length: ");
                    int length = int.Parse(Console.ReadLine());
                    Console.WriteLine(Input.Substring(startIndex, length));
                    break;
                case 9:
                    Console.WriteLine("Checking: ");
                    string checkString = Console.ReadLine();
                    Console.WriteLine(Input.StartsWith(checkString));
                    break;
                case 10:
                    Console.WriteLine("Checking: ");
                    char delimiter = char.Parse(Console.ReadLine());
                    string[] splitArray = Input.Split(delimiter);
                    foreach (string s in splitArray)
                    {
                        Console.WriteLine(s);
                    }
                    break;
                case 11:
                    Console.WriteLine("Checking: ");
                    string checkString2 = Console.ReadLine();
                    Console.WriteLine(Input.EndsWith(checkString2));
                    break;
                case 12:
                    Console.WriteLine("Checking: ");
                    string findSubstring = Console.ReadLine();
                    Console.WriteLine(Input.IndexOf(findSubstring));
                    break;
                case 13:
                    Console.WriteLine("Checking: ");
                    string findSubstring2 = Console.ReadLine();
                    Console.WriteLine(Input.LastIndexOf(findSubstring2));
                    break;
                case 14:
                    Console.WriteLine("Replacing: ");
                    string replaceSubstring = Console.ReadLine();
                    Console.WriteLine("Checking: ");
                    string newSubstring = Console.ReadLine();
                    Console.WriteLine(Input.Replace(replaceSubstring, newSubstring));
                    break;
                case 15:
                    char[] charArray = Input.ToCharArray();
                    Array.Reverse(charArray);
                    Console.WriteLine(new string(charArray));
                    break;
                default:
                    Console.WriteLine("Invalid!!! ");
                    break;
            }
        }

        static void Sets()
        {
            int[] X = { 10, 22, 30, 44, 55 };
            int[] Y = { 1, 22, 8, 44, 16, 9 };
            int[] intersection = new int[Math.Min(X.Length, Y.Length)];
            int count = 0;


            for (int i = 0; i < X.Length; i++)
            {
                for (int j = 0; j < Y.Length; j++)
                {
                    if (X[i] == Y[j])
                    {
                        intersection[count++] = X[i];
                        break;
                    }
                }
            }

            Console.WriteLine("The intersection of X and Y is: { ");
            for (int i = 0; i < count; i++)
            {
                Console.Write(intersection[i] + " ");
            }
            Console.WriteLine("}");

            Console.ReadKey();
        }

        static void RunStacks()
        {
            Stack sampleStack = new Stack();
            char ans;
            int b;
        selection:
            Console.Clear();
            Console.WriteLine("Stack Example");
            Console.WriteLine(" ");
            Console.Write("Enter number of Elements: ");
            b = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= b; i++)
            {
                sampleStack.Push(i); Console.WriteLine("Pushed item " + i + ": " + i);
            }
            Console.WriteLine(" ");
            Console.WriteLine("Stack Name: sampleStack");
            Console.WriteLine(" ");
            Console.WriteLine("Count: " + b);
            Console.WriteLine(" ");
            Console.WriteLine("Arrangement of items in sampleStack: ");
            Console.WriteLine("------------- ");
            foreach (int i in sampleStack)
            {
                Console.WriteLine("| " + i + "| ");
            }
            Console.WriteLine(" ");
            Console.Write("Try Again? [Y/N]:");
            ans = Convert.ToChar(Console.ReadLine());
            if (ans == 'Y' || ans == 'y')
            {
                goto selection;
            }
            else
            {
                Environment.Exit(0);
            }

            Console.ReadKey();
        }

        static void RunSets()
        {
            int[] X = { 10, 22, 30, 44, 55 };
            int[] Y = { 1, 22, 8, 44, 16, 9 };
            int[] intersection = new int[Math.Min(X.Length, Y.Length)];
            int count = 0;


            for (int i = 0; i < X.Length; i++)
            {
                for (int j = 0; j < Y.Length; j++)
                {
                    if (X[i] == Y[j])
                    {
                        intersection[count++] = X[i];
                        break;
                    }
                }
            }

            Console.WriteLine("The intersection of X and Y is: { ");
            for (int i = 0; i < count; i++)
            {
                Console.Write(intersection[i] + " ");
            }
            Console.WriteLine("}");

            Console.ReadKey();
        }

        static void RunQueue()
        {
            Queue queue = new Queue();

            int choice;
            do
            {
                Console.WriteLine("\nChoose from:");
                Console.WriteLine("1 - Enqueue");
                Console.WriteLine("2 - Dequeue");
                Console.WriteLine("3 - Display");
                Console.WriteLine("4 - Exit");
                Console.Write("Enter your choice: ");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                   case 1:
                     Console.Write("Enter element you want to enqueue: ");
                     int element = int.Parse(Console.ReadLine());
                     queue.Enqueue(element);
                     Console.WriteLine("Element added!");
                   break;
                   case 2:
                     if (queue.Count == 0)
                     {
                      Console.WriteLine("Queue is empty!");
                     }
                   else
                   {
                     queue.Dequeue();
                     Console.WriteLine("Element deleted!");
                   }
                   break;
                   case 3:
                   if (queue.Count == 0)
                   {
                     Console.WriteLine("Queue is empty!");
                   }
                   else
                   {
                     Console.Write("Elements in the queue are: ");
                   foreach (int q in queue)
                   {
                     Console.Write(q + " ");
                   }
                     Console.WriteLine();
                   }
                   break;
                   case 4:
                     Console.WriteLine("Exiting program...");
                     break;
                    default:
                        Console.WriteLine("Invalid choice! Try again!");
                        break;
                }
            }while (choice != 4);
        }

        static void LinkedLists()
        {
            LinkedList<int> l = new LinkedList<int>();

            var nn = l.AddFirst(10);
            l.AddAfter(nn, 444);
            l.AddFirst(20);
            l.AddFirst(10);

            var nn2 = l.AddLast(40);
            l.AddBefore(nn2, 333);
            l.AddLast(50);
            l.AddLast(60);

            Console.WriteLine("Originl list number: ");
            Console.WriteLine("10");
            Console.WriteLine("20");
            Console.WriteLine("30");
            Console.WriteLine("40");
            Console.WriteLine("50");
            Console.WriteLine("60");
            Console.WriteLine("");
            Console.WriteLine("New list number: ");

            foreach (int str in l)
            {
                Console.Write(str + " ");
            }
            Console.ReadKey();
        }

        static void BinaryTree()
        {
            double result;

            result = Math.Pow('V', 'A') / 'C' + ('C' - 'I' * Math.Pow('N', 'E') / Math.Pow('S', 'N') + 'O' + 'W');
            Console.WriteLine("(V ^ A / C) + (C - I * N ^ E / S ^ N + O + W) = " + result);

            result = 'A' / 'D' * Math.Pow('A', 'M') - 'S' * Math.Pow('O', 'N' + 'U');
            Console.WriteLine("(A / D * A ^ M - S) * O ^ (N + U) = " + result);

            result = 'F' * 'A' / 'L' + ('C' + 'O' / 'N' * 'S');
            Console.WriteLine("(F * A / L) + (C + O / N * S) = " + result);
        }

        static void Graph()
        {
            Console.WriteLine("This option is unavailble as it has different Project.");
        }

        static void Sorting()
        {
            Console.WriteLine("Enter a series of integers (separated ny spaces): ");
            string input = Console.ReadLine();
            string[] numbers = input.Split(' ');

            int[] arr = new int[numbers.Length];
            for (int i = 0; i < numbers.Length; i++)
            {
                arr[i] = int.Parse(numbers[i]);
            }
            Console.WriteLine("Original Array: ");
            PrintArray(arr);

            BubbleSort(arr);
            Console.WriteLine("Array after Bubble Sort (ascending order): ");
            PrintArray(arr);

            InsertionSort(arr);
            Console.WriteLine("Array after Insertion Sort (ascending order): ");
            PrintArray(arr);

            SelectionSort(arr);
            Console.WriteLine("Array after Selection Sort (ascending order): ");
            PrintArray(arr);
            
            Array.Reverse(arr);
            Console.WriteLine("Array in descending order: ");
            PrintArray(arr);

            static void BubbleSort(int[] arr)
            {
                int n = arr.Length;

                for (int i = 0; i < n - 1; i++)
                {
                    for (int j = 0; j < n - i - 1; j++)
                    {
                        if (arr[j] > arr[j + 1])
                        {
                            int temp = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }
            }

            static void InsertionSort(int[] arr)
            {
                int n = arr.Length;

                for (int i = 1; i < n; i++)
                {
                    int key = arr[i];
                    int j = i - 1;

                    while (j >= 0 && arr[j] > key)
                    {
                        arr[j + 1] = arr[j];
                        j--;
                    }
                    arr[j + 1] = key;
                }
            }

            static void SelectionSort(int[] arr)
            {
                int n = arr.Length;

                for (int i = 0; i < n - 1; i++)
                {
                    int minIndex = i;

                    for (int j = i + 1; j < n; j++)
                    {
                        if (arr[j] < arr[minIndex])
                        {
                            minIndex = j;
                        }
                    }

                    int temp = arr[minIndex];
                    arr[minIndex] = arr[i];
                    arr[i] = temp;
                }
            }

            static void PrintArray(int[] arr)
            {
                foreach (int num in arr)
                {
                    Console.Write(num + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
